#!/usr/bin/env bash
set -euo pipefail
EXPECTED_BRANCH="p0-launch-20260902"
EXPECTED_HEAD="3df3604"
BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_DIR="${1:-$PWD}"
cd "$REPO_DIR"
if [ ! -d .git ]; then echo "ERROR: شغّل الحزمة من جذر مستودع سنع"; exit 1; fi
BRANCH="$(git branch --show-current)"
HEAD="$(git rev-parse --short HEAD)"
if [ "$BRANCH" != "$EXPECTED_BRANCH" ]; then echo "ERROR: الفرع الحالي $BRANCH وليس $EXPECTED_BRANCH"; exit 1; fi
if [ "$HEAD" != "$EXPECTED_HEAD" ]; then echo "ERROR: HEAD الحالي $HEAD وليس $EXPECTED_HEAD — توقف للمراجعة ولا تعمل Pull/Sync"; exit 1; fi
cp -a "$BUNDLE_DIR/payload/." "$REPO_DIR/"
cd "$REPO_DIR/sana_full"
python -m py_compile app.py sana_articles.py sana_content_governance.py sana_human_review.py sana_billing.py sana_knowledge.py seed_article_founder_dependency.py test_client_copy_simplification.py test_expert_review_slice.py test_public_seo.py test_customer_journey_isolation.py
python -m unittest -v test_client_copy_simplification.py
python - <<'PY'
import sys
sys.path.insert(0,'.')
import sana_articles, sana_content_governance
assert len(sana_articles.ARTICLES) == 30
assert len({a['slug'] for a in sana_articles.ARTICLES}) == 30
assert len(sana_content_governance.SAFE_ARTICLE_BACKLOG) == 100
sana_articles.validate_public_catalog(sana_articles.ARTICLES)
print('CONTENT_VALIDATION PASS')
PY
cd "$REPO_DIR"
git diff --check -- $(cat "$BUNDLE_DIR/FILES.txt")
echo "UPDATE_APPLIED_AND_STATIC_CHECKS_PASS"
echo "لم يتم commit أو push"
