#!/usr/bin/env bash
set -euo pipefail
EXPECTED_BRANCH="p0-launch-20260902"
BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_DIR="${1:-$PWD}"
cd "$REPO_DIR"
BRANCH="$(git branch --show-current)"
if [ "$BRANCH" != "$EXPECTED_BRANCH" ]; then echo "ERROR: الفرع الحالي $BRANCH وليس $EXPECTED_BRANCH"; exit 1; fi
mapfile -t FILES < "$BUNDLE_DIR/FILES.txt"
git add -- "${FILES[@]}"
git diff --cached --check
echo "--- staged files ---"
git diff --cached --name-status
git commit -m "Improve Sana public content discovery expert review and report access"
git push origin "$EXPECTED_BRANCH"
echo "PUSH_REQUESTED_NO_FORCE"
