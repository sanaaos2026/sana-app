-- سنع — النواة الأساسية (7 جداول فقط)
-- Sana Core Schema v1 (MVP starting point)

CREATE TABLE companies (
    company_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    sector TEXT,
    city TEXT,
    stage TEXT,
    employee_count INTEGER,
    annual_revenue REAL,
    vision TEXT,
    main_goal TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE users (
    user_id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT,
    department TEXT,
    status TEXT DEFAULT 'نشط',
    FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

CREATE TABLE cases (
    case_id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    case_title TEXT NOT NULL,
    case_type TEXT,
    case_status TEXT DEFAULT 'Open',
    declared_problem TEXT,
    real_question TEXT,
    related_asset_id TEXT,
    confidence_score INTEGER,
    value_impact_estimate TEXT,
    ai_analysis TEXT,
    opened_at TEXT DEFAULT (datetime('now')),
    closed_at TEXT,
    FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

CREATE TABLE assets (
    asset_id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    asset_type TEXT NOT NULL,
    asset_name TEXT NOT NULL,
    current_score INTEGER,
    fragility_score INTEGER,
    owner_user_id TEXT,
    status TEXT,
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

CREATE TABLE evidence (
    evidence_id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    case_id TEXT,
    asset_id TEXT,
    title TEXT NOT NULL,
    source_type TEXT,
    confidence INTEGER,
    ai_analysis TEXT,
    ai_suggested_asset_id TEXT,
    date_collected TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (company_id) REFERENCES companies(company_id),
    FOREIGN KEY (case_id) REFERENCES cases(case_id)
);

CREATE TABLE decisions (
    decision_id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    case_id TEXT,
    asset_id TEXT,
    title TEXT NOT NULL,
    recommended_action TEXT,
    reason TEXT,
    confidence_score INTEGER,
    expected_impact TEXT,
    status TEXT DEFAULT 'مقترح',
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (company_id) REFERENCES companies(company_id),
    FOREIGN KEY (case_id) REFERENCES cases(case_id),
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
);

CREATE TABLE tasks (
    task_id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL,
    decision_id TEXT,
    title TEXT NOT NULL,
    owner_user_id TEXT,
    due_date TEXT,
    status TEXT DEFAULT 'لم تبدأ',
    priority TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    completed_at TEXT,
    FOREIGN KEY (company_id) REFERENCES companies(company_id),
    FOREIGN KEY (decision_id) REFERENCES decisions(decision_id)
);

-- الجدول الثامن (أُضيف لاحقًا): يسمح لقرار واحد أن يرفع عدة أصول دفعة واحدة
-- بدل الاقتصار على أصل واحد فقط (asset_id في جدول decisions يبقى "الأصل الأساسي" للعرض،
-- لكن هذا الجدول هو من يحكم فعليًا أي الأصول ترتفع وبكم عند إنجاز المهمة).
CREATE TABLE decision_asset_impacts (
    impact_id TEXT PRIMARY KEY,
    decision_id TEXT NOT NULL,
    asset_id TEXT NOT NULL,
    score_impact INTEGER NOT NULL,
    is_primary INTEGER DEFAULT 0,
    FOREIGN KEY (decision_id) REFERENCES decisions(decision_id),
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
);

-- الجدول التاسع: أطر عمل عامة (منهجيات مستقلة عن أي شركة بعينها)
-- مثل "نظام سنع لجلب العملاء" — يُكتب مرة واحدة، ويُربط بأي عدد من القضايا.
CREATE TABLE frameworks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    subtitle TEXT,
    doc_type TEXT DEFAULT 'framework',
    version TEXT DEFAULT 'v1.0',
    content_json TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- الجدول العاشر: جدول ربط — يسمح لأي قضية (case) أن ترتبط بأي إطار عمل
-- بدون تكرار محتوى الإطار داخل بيانات القضية.
CREATE TABLE case_frameworks (
    case_id TEXT NOT NULL,
    framework_slug TEXT NOT NULL,
    linked_at TEXT DEFAULT (datetime('now')),
    PRIMARY KEY (case_id, framework_slug),
    FOREIGN KEY (case_id) REFERENCES cases(case_id),
    FOREIGN KEY (framework_slug) REFERENCES frameworks(slug)
);

