"""
سنع — الخادم الأساسي (MVP الحقيقي)
Sana Core Backend — Flask + SQLite + Claude AI

تشغيل:
    python3 app.py
ثم افتح المتصفح على:
    http://localhost:5000

⚠ للذكاء الاصطناعي: يحتاج متغيّر بيئة ANTHROPIC_API_KEY
(على Replit: أضفه من قسم Secrets في الشريط الجانبي)
"""
import sqlite3
import os
import json
import uuid
from datetime import datetime
from flask import Flask, jsonify, request, render_template, g, session, redirect, url_for

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "sana.db")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "sana-demo-secret-change-me")

# رمز دخول اختياري لحماية النسخة التجريبية عند إرسالها لعملاء محتملين.
# اتركه فارغًا أثناء التطوير المحلي — يُفعَّل تلقائيًا فقط إذا ضُبط متغيّر البيئة.
DEMO_ACCESS_CODE = os.environ.get("DEMO_ACCESS_CODE", "").strip()

# رمز بسيط لحماية نقطة إعادة تعيين البيانات التجريبية من الاستخدام العشوائي.
DEMO_RESET_TOKEN = os.environ.get("DEMO_RESET_TOKEN", "sana-reset").strip()

ASSET_TYPES = ["Knowledge", "Operations", "Brand", "Data", "Independence"]


@app.before_request
def require_access_code():
    """بوابة دخول اختيارية — تُفعَّل فقط إذا ضُبط DEMO_ACCESS_CODE كمتغيّر بيئة.
    مصمَّمة لحماية النسخة التجريبية عند مشاركتها مع عملاء محتملين خارج فريقك."""
    if not DEMO_ACCESS_CODE:
        return  # البوابة معطّلة افتراضيًا
    if request.endpoint in ("access_gate", "static", "system_health"):
        return
    if session.get("sana_access_granted"):
        return
    return redirect(url_for("access_gate"))


@app.route("/access", methods=["GET", "POST"])
def access_gate():
    error = None
    if request.method == "POST":
        if request.form.get("code", "").strip() == DEMO_ACCESS_CODE:
            session["sana_access_granted"] = True
            return redirect("/")
        error = "الرمز غير صحيح — تأكد منه مع فريق سنع."
    return render_template("08-access.html", error=error)


def ask_sana_ai(system_prompt, user_prompt):
    """
    نداء حقيقي لـ Claude — هذا أول اتصال فعلي بذكاء اصطناعي في سنع، بدل أي حساب مبرمج يدويًا.
    يحتاج ANTHROPIC_API_KEY كمتغيّر بيئة (على Replit: أضفه من قسم Secrets).
    """
    try:
        import anthropic
    except ImportError:
        return {"error": "مكتبة anthropic غير مثبَّتة — شغّل: pip install anthropic"}

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return {"error": "ANTHROPIC_API_KEY غير موجود — أضفه في Secrets على Replit أولاً"}

    try:
        client = anthropic.Anthropic(api_key=api_key)
        response = client.messages.create(
            model="claude-sonnet-5",
            max_tokens=1000,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )
        raw_text = "".join(
            block.text for block in response.content if getattr(block, "type", "") == "text"
        )
        # طبقة أمان: أحيانًا يُغلِّف النموذج الرد بـ ```json رغم التعليمات الصريحة بعدم ذلك
        cleaned = raw_text.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("```")[1]
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
        return {"raw_text": cleaned.strip()}
    except Exception as e:
        return {"error": f"فشل الاتصال بالذكاء الاصطناعي: {str(e)}"}


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(force=False):
    if force and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    fresh = not os.path.exists(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    if fresh:
        with open(os.path.join(BASE_DIR, "schema.sql"), "r", encoding="utf-8") as f:
            conn.executescript(f.read())
        conn.commit()
    else:
        # ترحيل خفيف: يضيف الجدول الجديد لقاعدة بيانات موجودة أصلاً بدون مسح أي بيانات
        conn.execute("""CREATE TABLE IF NOT EXISTS decision_asset_impacts (
            impact_id TEXT PRIMARY KEY,
            decision_id TEXT NOT NULL,
            asset_id TEXT NOT NULL,
            score_impact INTEGER NOT NULL,
            is_primary INTEGER DEFAULT 0,
            FOREIGN KEY (decision_id) REFERENCES decisions(decision_id),
            FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
        )""")
        # ترحيل جدول أطر العمل العامة (frameworks) — لا يمس أي بيانات موجودة
        conn.execute("""CREATE TABLE IF NOT EXISTS frameworks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slug TEXT UNIQUE NOT NULL,
            title TEXT NOT NULL,
            subtitle TEXT,
            doc_type TEXT DEFAULT 'framework',
            version TEXT DEFAULT 'v1.0',
            content_json TEXT NOT NULL,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS case_frameworks (
            case_id TEXT NOT NULL,
            framework_slug TEXT NOT NULL,
            linked_at TEXT DEFAULT (datetime('now')),
            PRIMARY KEY (case_id, framework_slug),
            FOREIGN KEY (case_id) REFERENCES cases(case_id),
            FOREIGN KEY (framework_slug) REFERENCES frameworks(slug)
        )""")
        # ترحيل أعمدة الذكاء الاصطناعي — SQLite لا يدعم "ADD COLUMN IF NOT EXISTS"،
        # لذا نحاول ونتجاهل الخطأ إن كان العمود موجودًا مسبقًا.
        for alter_stmt in [
            "ALTER TABLE evidence ADD COLUMN ai_analysis TEXT",
            "ALTER TABLE evidence ADD COLUMN ai_suggested_asset_id TEXT",
            "ALTER TABLE cases ADD COLUMN ai_analysis TEXT",
        ]:
            try:
                conn.execute(alter_stmt)
            except sqlite3.OperationalError:
                pass  # العمود موجود مسبقًا — طبيعي تمامًا
        conn.commit()
    conn.close()
    return fresh


def seed_decision_impacts():
    """يربط قرار D001 بثلاثة أصول (لا أصل واحد) — يعمل حتى لو كانت الشركة مزروعة مسبقًا."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM decision_asset_impacts")
    if cur.fetchone()[0] > 0:
        conn.close()
        return  # already seeded

    cur.execute("SELECT decision_id FROM decisions WHERE decision_id='D001'")
    if not cur.fetchone():
        conn.close()
        return  # لا يوجد D001 بعد (قاعدة بيانات فارغة تمامًا، ستُزرع لاحقًا)

    # توثيق SOP يرفع أصل المعرفة مباشرة (+5)، وأصل التشغيل والاستقلال بشكل غير مباشر (+3 لكل منهما)
    # يطابق فلسفة سنع: "قرار واحد قد يرفع عدة أصول مترابطة دفعة واحدة"
    impacts = [
        ("IMP-D001-A001", "D001", "A001", 5, 1),   # المعرفة — الأصل المباشر
        ("IMP-D001-A002", "D001", "A002", 3, 0),   # التشغيل — أثر ثانوي
        ("IMP-D001-A005", "D001", "A005", 3, 0),   # الاستقلال — أثر ثانوي (هذا كان ناقصًا)
    ]
    cur.executemany("""INSERT INTO decision_asset_impacts
        (impact_id, decision_id, asset_id, score_impact, is_primary)
        VALUES (?,?,?,?,?)""", impacts)
    conn.commit()
    conn.close()


SANA_ACQUISITION_SYSTEM = {
    "slug": "sana-acquisition-system",
    "title": "نظام سنع لجلب العملاء",
    "subtitle": "Sana Acquisition System",
    "principle": "كل نقطة اتصال يجب أن تقرّب العميل من قرار الشراء. لا نبني \"قسم تسويق\" ولا \"قسم مبيعات\" كوحدتين منفصلتين — بل نظام جلب عملاء واحد متكامل.",
    "rule_groups": [
        {
            "title": "القواعد التأسيسية العشر",
            "rules": [
                "لا تبدأ بالنشر، ابدأ بالوجهة: من العميل؟ ماذا يريد؟ لماذا يشتري؟ لماذا يرفض؟",
                "لا تسوّق للجميع — كلما ضاقت الفئة المستهدفة ارتفع معدل التحويل.",
                "لا تبع الخدمة، بع النتيجة: زيادة مبيعات، توفير وقت، تقليل خسائر، راحة، وضوح.",
                "ابنِ الثقة قبل طلب الشراء — كل محتوى يقوم بأحد ثلاثة أدوار: تثقيف، إثبات، أو طمأنة.",
                "كل محتوى يقود إلى خطوة واحدة فقط: حجز، رسالة، زيارة، تحميل، أو اشتراك.",
                "الإعلان يضاعف الموجود ولا يصنع النجاح — عرض ضعيف + إعلان = فشل أسرع.",
                "لا تعتمد على قناة واحدة — العميل يجب أن يراك أكثر من مرة عبر مسار متعدد القنوات.",
                "سرعة الاستجابة جزء من التسويق — كل دقيقة تأخير تنقص احتمالية الإغلاق.",
                "كل عميل محتمل يدخل النظام (CRM، متابعة، تصنيف، قياس) — لا \"أرسل واتساب وانتهى\".",
                "ما لا يُقاس لا يمكن تطويره — قياس أسبوعي: الزوار ← العملاء المحتملون ← الاجتماعات ← العروض ← المبيعات ← الإيرادات.",
            ],
        },
        {
            "title": "قواعد التواجد الرقمي",
            "rules": [
                "كل منصة لها وظيفة واضحة: TikTok للاكتشاف، Instagram لبناء الثقة، LinkedIn لبناء السلطة، YouTube للتعليم، Google لمن يبحث ويقارن، الموقع للتحويل، WhatsApp للإغلاق.",
                "كل صفحة لها هدف واحد فقط (CTA واحد).",
                "الموقع مندوب مبيعات يعمل 24 ساعة، وليس تعريفًا بالشركة.",
                "الهوية موحدة بالكامل: الشعار، اللغة، الألوان، الرسائل، الوعود.",
                "كل نقطة اتصال تجيب عن سؤال واحد: لماذا أثق بك؟",
            ],
        },
        {
            "title": "قواعد المبيعات",
            "rules": [
                "شخّص ثم بع.",
                "الأسئلة أهم من العرض.",
                "الاعتراضات تعني نقص وضوح، لا رفضًا نهائيًا.",
                "كل عرض يوضح بالترتيب: المشكلة ← التكلفة ← الحل ← النتيجة ← الخطوة التالية.",
                "المتابعة ليست إزعاجًا، بل جزء من الخدمة.",
            ],
        },
    ],
    "clarity_rule": "أي نشاط لا يخدم انتقال العميل إلى المرحلة التالية فهو هدر.",
    "stages": [
        {"name": "يُرى", "goal": "صناعة الوعي", "question": "كيف يكتشفنا العميل؟"},
        {"name": "يثق", "goal": "بناء الثقة", "question": "لماذا يختارنا؟"},
        {"name": "يتواصل", "goal": "توليد Leads", "question": "كيف يبدأ العلاقة؟"},
        {"name": "يشتري", "goal": "التحويل", "question": "كيف نغلق الصفقة؟"},
        {"name": "يبقى ويُوصي", "goal": "الاحتفاظ والإحالات", "question": "كيف نزيد القيمة؟"},
    ],
}


def seed_frameworks():
    """يزرع 'نظام سنع لجلب العملاء' كأول إطار عمل عام، ويربطه بقضية CS001 كمثال حي.
    آمن للتشغيل المتكرر: يحدّث المحتوى إن تغيّر (ON CONFLICT)، ولا يكرر الربط (INSERT OR IGNORE)."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    fw = SANA_ACQUISITION_SYSTEM
    cur.execute("""
        INSERT INTO frameworks (slug, title, subtitle, doc_type, version, content_json, created_at, updated_at)
        VALUES (?, ?, ?, 'framework', 'v1.0', ?, datetime('now'), datetime('now'))
        ON CONFLICT(slug) DO UPDATE SET
            title=excluded.title, subtitle=excluded.subtitle,
            content_json=excluded.content_json, updated_at=datetime('now')
    """, (fw["slug"], fw["title"], fw["subtitle"], json.dumps(fw, ensure_ascii=False)))

    # اربطه بأي قضية موجودة فعليًا (مثل CS001) — لا نفترض وجود CS002 لأنها لم تُزرع بعد
    cur.execute("SELECT case_id FROM cases")
    existing_cases = [row[0] for row in cur.fetchall()]
    for cid in existing_cases:
        cur.execute("""INSERT OR IGNORE INTO case_frameworks (case_id, framework_slug)
                        VALUES (?, ?)""", (cid, fw["slug"]))

    conn.commit()
    conn.close()


# ------------------------------------------------------------------
# عزل تجريبي لكل زائر (Per-visitor sandbox)
# ------------------------------------------------------------------
# كل شخص يفتح الرابط لأول مرة يحصل على نسخة خاصة به من شركة C001 النموذجية —
# بياناته وقراراته لا يشاركها أحد آخر، حتى لو جرّب عشرة أشخاص الرابط في نفس اللحظة.

def clone_demo_company():
    """ينسخ الشركة النموذجية C001 (وكل أصولها وقضاياها وأدلتها) إلى شركة جديدة
    معزولة تمامًا بمعرّفات فريدة، ويربط قضيتها الرئيسية بنفس أطر العمل العامة."""
    db = get_db()
    new_company_id = "C" + uuid.uuid4().hex[:8].upper()

    company = db.execute("SELECT * FROM companies WHERE company_id='C001'").fetchone()
    db.execute("""INSERT INTO companies
        (company_id, name, sector, city, stage, employee_count, annual_revenue, vision, main_goal)
        VALUES (?,?,?,?,?,?,?,?,?)""",
        (new_company_id, company["name"], company["sector"], company["city"], company["stage"],
         company["employee_count"], company["annual_revenue"], company["vision"], company["main_goal"]))

    id_map_users = {}
    for u in db.execute("SELECT * FROM users WHERE company_id='C001'").fetchall():
        new_uid = "U" + uuid.uuid4().hex[:8].upper()
        id_map_users[u["user_id"]] = new_uid
        db.execute("""INSERT INTO users (user_id, company_id, name, role, department, status)
            VALUES (?,?,?,?,?,?)""",
            (new_uid, new_company_id, u["name"], u["role"], u["department"], u["status"]))

    # الأصول: نحافظ على نفس اللاحقة (A001..A005) خلف بادئة الشركة الجديدة،
    # حتى تبقى صفحة "تقييم الأصول" (06-assessment) قادرة على تعيينها بلا كسر.
    id_map_assets = {}
    for a in db.execute("SELECT * FROM assets WHERE company_id='C001'").fetchall():
        suffix = a["asset_id"].replace("A", "", 1) if a["asset_id"].startswith("A") else a["asset_id"]
        new_aid = f"{new_company_id}-A{suffix}"
        id_map_assets[a["asset_id"]] = new_aid
        db.execute("""INSERT INTO assets
            (asset_id, company_id, asset_type, asset_name, current_score, fragility_score, owner_user_id, status)
            VALUES (?,?,?,?,?,?,?,?)""",
            (new_aid, new_company_id, a["asset_type"], a["asset_name"], a["current_score"],
             a["fragility_score"], id_map_users.get(a["owner_user_id"]), a["status"]))

    id_map_cases = {}
    new_case_id = None
    for c in db.execute("SELECT * FROM cases WHERE company_id='C001'").fetchall():
        new_cid = "CS" + uuid.uuid4().hex[:6].upper()
        id_map_cases[c["case_id"]] = new_cid
        if new_case_id is None:
            new_case_id = new_cid
        db.execute("""INSERT INTO cases
            (case_id, company_id, case_title, case_type, case_status, declared_problem,
             real_question, related_asset_id, confidence_score, value_impact_estimate, ai_analysis)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (new_cid, new_company_id, c["case_title"], c["case_type"], c["case_status"],
             c["declared_problem"], c["real_question"], id_map_assets.get(c["related_asset_id"]),
             c["confidence_score"], c["value_impact_estimate"], c["ai_analysis"]))

    id_map_evidence = {}
    for e in db.execute("SELECT * FROM evidence WHERE company_id='C001'").fetchall():
        new_eid = "E" + uuid.uuid4().hex[:8].upper()
        id_map_evidence[e["evidence_id"]] = new_eid
        db.execute("""INSERT INTO evidence
            (evidence_id, company_id, case_id, asset_id, title, source_type, confidence,
             ai_analysis, ai_suggested_asset_id)
            VALUES (?,?,?,?,?,?,?,?,?)""",
            (new_eid, new_company_id, id_map_cases.get(e["case_id"]), id_map_assets.get(e["asset_id"]),
             e["title"], e["source_type"], e["confidence"], e["ai_analysis"],
             id_map_assets.get(e["ai_suggested_asset_id"])))

    id_map_decisions = {}
    for d in db.execute("SELECT * FROM decisions WHERE company_id='C001'").fetchall():
        new_did = "D" + uuid.uuid4().hex[:8].upper()
        id_map_decisions[d["decision_id"]] = new_did
        db.execute("""INSERT INTO decisions
            (decision_id, company_id, case_id, asset_id, title, recommended_action, reason,
             confidence_score, expected_impact, status)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (new_did, new_company_id, id_map_cases.get(d["case_id"]), id_map_assets.get(d["asset_id"]),
             d["title"], d["recommended_action"], d["reason"], d["confidence_score"],
             d["expected_impact"], d["status"]))

    for t in db.execute("SELECT * FROM tasks WHERE company_id='C001'").fetchall():
        new_tid = "TSK" + uuid.uuid4().hex[:8].upper()
        db.execute("""INSERT INTO tasks
            (task_id, company_id, decision_id, title, owner_user_id, due_date, status, priority)
            VALUES (?,?,?,?,?,?,?,?)""",
            (new_tid, new_company_id, id_map_decisions.get(t["decision_id"]), t["title"],
             id_map_users.get(t["owner_user_id"]), t["due_date"], t["status"], t["priority"]))

    impacts = db.execute("""SELECT di.* FROM decision_asset_impacts di
        JOIN decisions d ON di.decision_id = d.decision_id WHERE d.company_id='C001'""").fetchall()
    for imp in impacts:
        new_impid = "IMP" + uuid.uuid4().hex[:8].upper()
        db.execute("""INSERT INTO decision_asset_impacts (impact_id, decision_id, asset_id, score_impact, is_primary)
            VALUES (?,?,?,?,?)""",
            (new_impid, id_map_decisions.get(imp["decision_id"]), id_map_assets.get(imp["asset_id"]),
             imp["score_impact"], imp["is_primary"]))

    for fw in db.execute("SELECT framework_slug FROM case_frameworks WHERE case_id='CS001'").fetchall():
        db.execute("INSERT OR IGNORE INTO case_frameworks (case_id, framework_slug) VALUES (?, ?)",
                   (new_case_id, fw["framework_slug"]))

    db.commit()
    return new_company_id, new_case_id


def ensure_session_company():
    """يعيد (company_id, case_id) الخاصين بجلسة هذا الزائر تحديدًا، وينشئهما
    عبر نسخة معزولة جديدة إذا كانت هذه أول زيارة له."""
    company_id = session.get("company_id")
    case_id = session.get("case_id")
    if company_id and case_id:
        db = get_db()
        exists = db.execute("SELECT 1 FROM companies WHERE company_id=?", (company_id,)).fetchone()
        if exists:
            return company_id, case_id
    company_id, case_id = clone_demo_company()
    session["company_id"] = company_id
    session["case_id"] = case_id
    return company_id, case_id


def seed_db():
    """يزرع بيانات أثر مشرق كأول شركة حقيقية على النظام."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM companies")
    if cur.fetchone()[0] > 0:
        conn.close()
        return  # already seeded

    cur.execute("""INSERT INTO companies
        (company_id, name, sector, city, stage, employee_count, annual_revenue, vision, main_goal)
        VALUES (?,?,?,?,?,?,?,?,?)""",
        ("C001", "أثر مشرق", "عطور - تصنيع", "المدينة المنورة", "نمو", 8, 350000,
         "أن نكون أثر يُشم قبل أن يُرى", "رفع قيمة الشركة عبر أصل المعرفة"))

    cur.execute("""INSERT INTO users (user_id, company_id, name, role, department, status)
        VALUES (?,?,?,?,?,?)""",
        ("U001", "C001", "الزبير", "Owner", "الإدارة العامة", "نشط"))

    assets = [
        ("A001", "C001", "Knowledge", "أصل المعرفة", 18, 70, "U001", "يحتاج تطوير"),
        ("A002", "C001", "Operations", "أصل التشغيل", 41, 55, "U001", "متوسط"),
        ("A003", "C001", "Brand", "أصل البراند", 72, 20, "U001", "قوي"),
        ("A004", "C001", "Data", "أصل البيانات", 65, 30, "U001", "قوي"),
        ("A005", "C001", "Independence", "أصل الاستقلال", 22, 82, "U001", "مهدد"),
    ]
    cur.executemany("""INSERT INTO assets
        (asset_id, company_id, asset_type, asset_name, current_score, fragility_score, owner_user_id, status)
        VALUES (?,?,?,?,?,?,?,?)""", assets)

    cur.execute("""INSERT INTO cases
        (case_id, company_id, case_title, case_type, case_status, declared_problem, real_question,
         related_asset_id, confidence_score, value_impact_estimate)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        ("CS001", "C001", "ضعف توثيق العمليات", "Diagnostic Case", "Diagnosed",
         "نشعر أننا نعتمد كثيرًا على شخص واحد",
         "هل غياب أي موظف رئيسي يوقف الإنتاج فعليًا؟",
         "A001", 75, "رفع أصل المعرفة بمقدار 12 نقطة خلال شهر"))

    cur.execute("""INSERT INTO evidence
        (evidence_id, company_id, case_id, asset_id, title, source_type, confidence)
        VALUES (?,?,?,?,?,?,?)""",
        ("E001", "C001", "CS001", "A001",
         "لا يوجد ملف SOP موثق لأي عملية تصنيع", "ملاحظة مباشرة", 55))

    cur.execute("""INSERT INTO decisions
        (decision_id, company_id, case_id, asset_id, title, recommended_action, reason,
         confidence_score, expected_impact, status)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        ("D001", "C001", "CS001", "A001", "توثيق أول SOP للتصنيع",
         "بناء ملف SOP واحد لعملية التعبئة خلال 7 أيام",
         "أضعف مؤشر حاليًا هو تغطية التوثيق (22%)، وهو يهدد الاستقلال والجودة",
         75, "رفع أصل المعرفة من 18 إلى 30 خلال شهر", "قيد التنفيذ"))

    cur.execute("""INSERT INTO tasks
        (task_id, company_id, decision_id, title, owner_user_id, due_date, status, priority)
        VALUES (?,?,?,?,?,?,?,?)""",
        ("TSK001", "C001", "D001", "كتابة أول مسودة SOP لعملية التعبئة",
         "U001", "2026-07-14", "قيد التنفيذ", "عالية"))

    conn.commit()
    conn.close()


# ------------------------------------------------------------------
# Views — الصفحات الأربع
# ------------------------------------------------------------------

@app.route("/")
def entry():
    company_id, case_id = ensure_session_company()
    return render_template("00-entry.html", company_id=company_id, case_id=case_id)


@app.route("/home")
def ceo_home():
    company_id, case_id = ensure_session_company()
    return render_template("01-ceo-home.html", company_id=company_id, case_id=case_id)


@app.route("/case/new")
def new_case_form():
    company_id, case_id = ensure_session_company()
    return render_template("04-new-case.html", company_id=company_id)


@app.route("/sop-builder")
def sop_builder():
    company_id, case_id = ensure_session_company()
    return render_template("05-sop-builder.html", company_id=company_id, case_id=case_id)


@app.route("/assessment")
def assessment():
    company_id, case_id = ensure_session_company()
    return render_template("06-assessment.html", company_id=company_id, case_id=case_id)


@app.route("/case/<case_id>")
def case_workspace(case_id):
    db = get_db()
    case = db.execute("SELECT company_id FROM cases WHERE case_id=?", (case_id,)).fetchone()
    company_id = case["company_id"] if case else None
    return render_template("02-case-workspace.html", case_id=case_id, company_id=company_id)


@app.route("/passport")
def business_passport():
    company_id, case_id = ensure_session_company()
    return render_template("03-business-passport.html", company_id=company_id, case_id=case_id)


@app.route("/playbook/<slug>")
def playbook_view(slug):
    company_id, case_id = ensure_session_company()
    return render_template("07-acquisition-system.html", slug=slug, case_id=case_id)


# ------------------------------------------------------------------
# API — Companies
# ------------------------------------------------------------------

@app.route("/api/companies/<company_id>/summary")
def company_summary(company_id):
    db = get_db()
    company = db.execute("SELECT * FROM companies WHERE company_id=?", (company_id,)).fetchone()
    if not company:
        return jsonify({"success": False, "error": "COMPANY_NOT_FOUND"}), 404

    assets = db.execute("SELECT * FROM assets WHERE company_id=? ORDER BY current_score ASC",
                         (company_id,)).fetchall()
    cases = db.execute("SELECT * FROM cases WHERE company_id=?", (company_id,)).fetchall()
    decisions = db.execute(
        "SELECT * FROM decisions WHERE company_id=? ORDER BY created_at DESC", (company_id,)
    ).fetchall()
    tasks = db.execute("SELECT * FROM tasks WHERE company_id=?", (company_id,)).fetchall()
    evidence = db.execute("SELECT * FROM evidence WHERE company_id=?", (company_id,)).fetchall()

    weakest_asset = min(assets, key=lambda a: a["current_score"]) if assets else None
    strongest_asset = max(assets, key=lambda a: a["current_score"]) if assets else None
    open_decisions = [d for d in decisions if d["status"] in ("مقترح", "قيد التنفيذ")]

    avg_score = round(sum(a["current_score"] for a in assets) / len(assets)) if assets else 0

    return jsonify({
        "success": True,
        "data": {
            "company": dict(company),
            "quality_score": avg_score,
            "assets": [dict(a) for a in assets],
            "weakest_asset": dict(weakest_asset) if weakest_asset else None,
            "strongest_asset": dict(strongest_asset) if strongest_asset else None,
            "cases": [dict(c) for c in cases],
            "decisions": [dict(d) for d in decisions],
            "open_decisions_count": len(open_decisions),
            "top_decision": dict(open_decisions[0]) if open_decisions else None,
            "tasks": [dict(t) for t in tasks],
            "evidence_count": len(evidence),
        },
        "meta": {"generated_at": datetime.utcnow().isoformat() + "Z"}
    })


# ------------------------------------------------------------------
# API — Case Detail (شاشة القضية الكاملة)
# ------------------------------------------------------------------

@app.route("/api/cases/<case_id>")
def case_detail(case_id):
    db = get_db()
    case = db.execute("SELECT * FROM cases WHERE case_id=?", (case_id,)).fetchone()
    if not case:
        return jsonify({"success": False, "error": "CASE_NOT_FOUND"}), 404

    evidence = db.execute("SELECT * FROM evidence WHERE case_id=?", (case_id,)).fetchall()
    decisions = db.execute("SELECT * FROM decisions WHERE case_id=?", (case_id,)).fetchall()

    return jsonify({
        "success": True,
        "data": {
            "case": dict(case),
            "evidence": [dict(e) for e in evidence],
            "decisions": [dict(d) for d in decisions],
        }
    })


# ------------------------------------------------------------------
# API — System health (فحص جاهزية قبل إرسال النسخة التجريبية لعملاء)
# ------------------------------------------------------------------

@app.route("/api/system/health")
def system_health():
    """فحص بدون أي نداء فعلي لـ Claude (لا تكلفة، لا إنترنت لازم لهذا الفحص نفسه) —
    يتحقق فقط أن المكتبة مثبَّتة والمفتاح موجود، حتى تتأكد قبل إرسال الرابط لعميل محتمل."""
    checks = {"library_installed": False, "api_key_present": False}
    try:
        import anthropic  # noqa: F401
        checks["library_installed"] = True
    except ImportError:
        pass
    checks["api_key_present"] = bool(os.environ.get("ANTHROPIC_API_KEY"))
    checks["ai_ready"] = checks["library_installed"] and checks["api_key_present"]

    db = get_db()
    checks["database_connected"] = True
    checks["frameworks_seeded"] = db.execute("SELECT COUNT(*) c FROM frameworks").fetchone()["c"] > 0
    return jsonify({"success": True, "data": checks})


@app.route("/api/demo/reset", methods=["POST"])
def demo_reset():
    """يمسح كل التعديلات التي جربها عملاء سابقون (أدلة مضافة، قرارات معتمدة...) ويعيد
    البيانات إلى حالتها الأصلية — استخدمه بين إرسال النسخة لعميل محتمل وآخر."""
    token = request.args.get("token") or (request.get_json(silent=True) or {}).get("token")
    if token != DEMO_RESET_TOKEN:
        return jsonify({"success": False, "error": "INVALID_TOKEN"}), 403

    close_db()
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    init_db()
    seed_db()
    seed_decision_impacts()
    seed_frameworks()
    return jsonify({"success": True, "message": "تمت إعادة تعيين البيانات التجريبية بنجاح."})


# ------------------------------------------------------------------
# API — Frameworks (أطر عمل عامة، مثل نظام سنع لجلب العملاء)
# ------------------------------------------------------------------

@app.route("/api/frameworks/<slug>")
def framework_detail(slug):
    db = get_db()
    row = db.execute("SELECT * FROM frameworks WHERE slug=?", (slug,)).fetchone()
    if not row:
        return jsonify({"success": False, "error": "FRAMEWORK_NOT_FOUND"}), 404
    data = dict(row)
    data["content"] = json.loads(data.pop("content_json"))
    return jsonify({"success": True, "data": data})


@app.route("/api/cases/<case_id>/frameworks")
def case_linked_frameworks(case_id):
    db = get_db()
    rows = db.execute("""
        SELECT f.slug, f.title, f.subtitle, f.doc_type
        FROM frameworks f
        JOIN case_frameworks cf ON cf.framework_slug = f.slug
        WHERE cf.case_id = ?
        ORDER BY f.title
    """, (case_id,)).fetchall()
    return jsonify({"success": True, "data": [dict(r) for r in rows]})


# ------------------------------------------------------------------
# API — Business Passport (ملخص القيمة — معادلة مبسّطة مؤقتة)
# ------------------------------------------------------------------

@app.route("/api/companies/<company_id>/passport")
def passport_summary(company_id):
    db = get_db()
    company = db.execute("SELECT * FROM companies WHERE company_id=?", (company_id,)).fetchone()
    if not company:
        return jsonify({"success": False, "error": "COMPANY_NOT_FOUND"}), 404

    assets = db.execute("SELECT * FROM assets WHERE company_id=?", (company_id,)).fetchall()
    avg_score = round(sum(a["current_score"] for a in assets) / len(assets)) if assets else 0

    # ⚠ معادلة مبسّطة مؤقتة لأغراض العرض فقط — وليست محرك SVS الحقيقي.
    # السبب: بناء SQS/SVS الكامل (10 محاور + معادلة ضربية) خطوة لاحقة متعمَّدة
    # بعد أن يثبت هذا الهيكل الأساسي قيمته أولاً — راجع سجل القرارات في المحادثة.
    base = (company["annual_revenue"] or 0) * 2.5
    quality_multiplier = avg_score / 100
    current_value = round(base * quality_multiplier)
    potential_value = round(base * min((avg_score + 35) / 100, 1.1))

    weakest = min(assets, key=lambda a: a["current_score"]) if assets else None
    strongest = max(assets, key=lambda a: a["current_score"]) if assets else None

    return jsonify({
        "success": True,
        "data": {
            "company": dict(company),
            "quality_score": avg_score,
            "current_value": current_value,
            "potential_value": potential_value,
            "value_gap": potential_value - current_value,
            "assets": [dict(a) for a in assets],
            "weakest_asset": dict(weakest) if weakest else None,
            "strongest_asset": dict(strongest) if strongest else None,
        },
        "meta": {
            "disclaimer": "تقدير مبسّط للعرض فقط — ليس محرك SVS الرسمي المُوثَّق في المعمارية"
        }
    })


# ------------------------------------------------------------------
# API — Decisions
# ------------------------------------------------------------------

@app.route("/api/decisions/<decision_id>/approve", methods=["POST"])
def approve_decision(decision_id):
    db = get_db()
    decision = db.execute("SELECT * FROM decisions WHERE decision_id=?", (decision_id,)).fetchone()
    if not decision:
        return jsonify({"success": False, "error": "DECISION_NOT_FOUND"}), 404

    db.execute("UPDATE decisions SET status='معتمد' WHERE decision_id=?", (decision_id,))

    # القانون الأول: أي قرار معتمد يجب أن ينتج عنه مهمة تنفيذية فعلية
    existing_task = db.execute(
        "SELECT * FROM tasks WHERE decision_id=?", (decision_id,)
    ).fetchone()
    if not existing_task:
        db.execute("""INSERT INTO tasks (task_id, company_id, decision_id, title, status, priority)
            VALUES (?,?,?,?,?,?)""",
            (f"TSK-{decision_id}", decision["company_id"], decision_id,
             f"تنفيذ: {decision['title']}", "لم تبدأ", "عالية"))

    db.commit()
    return jsonify({"success": True, "data": {"decision_id": decision_id, "status": "معتمد"}})


@app.route("/api/decisions/<decision_id>/defer", methods=["POST"])
def defer_decision(decision_id):
    db = get_db()
    db.execute("UPDATE decisions SET status='قيد المراجعة' WHERE decision_id=?", (decision_id,))
    db.commit()
    return jsonify({"success": True, "data": {"decision_id": decision_id, "status": "قيد المراجعة"}})


# ------------------------------------------------------------------
# API — Tasks (إنجاز مهمة = يرفع الأصل تلقائيًا)
# ------------------------------------------------------------------

@app.route("/api/tasks/<task_id>/complete", methods=["POST"])
def complete_task(task_id):
    db = get_db()
    task = db.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
    if not task:
        return jsonify({"success": False, "error": "TASK_NOT_FOUND"}), 404
    if task["status"] == "منجزة":
        return jsonify({"success": False, "error": "TASK_ALREADY_COMPLETED",
                         "message": "هذه المهمة منجزة أصلاً."}), 400

    # ⚠ قاعدة سنع الأساسية: لا حكم بلا دليل — لا يمكن إنجاز مهمة (وبالتالي رفع درجة أصل)
    # بدون دليل واحد على الأقل مسجَّل في القضية المرتبطة بها.
    if task["decision_id"]:
        decision = db.execute(
            "SELECT * FROM decisions WHERE decision_id=?", (task["decision_id"],)
        ).fetchone()

        # ⚠ سد فجوة حقيقية: كان يمكن إنجاز المهمة قبل اعتماد القرار المرتبط بها إطلاقًا —
        # هذا يكسر الترتيب الأساسي في سنع: دليل → قرار → اعتماد → تنفيذ.
        if decision and decision["status"] not in ("معتمد", "قيد التنفيذ"):
            return jsonify({
                "success": False,
                "error": "DECISION_NOT_APPROVED",
                "message": "لا يمكن إنجاز هذه المهمة قبل اعتماد القرار المرتبط بها أولاً. افتح القضية واعتمد القرار قبل التنفيذ."
            }), 400

        if decision and decision["case_id"]:
            evidence_count = db.execute(
                "SELECT COUNT(*) as cnt FROM evidence WHERE case_id=?", (decision["case_id"],)
            ).fetchone()["cnt"]
            if evidence_count == 0:
                return jsonify({
                    "success": False,
                    "error": "EVIDENCE_REQUIRED",
                    "message": "لا يمكن إنجاز هذه المهمة قبل تسجيل دليل واحد على الأقل في القضية المرتبطة بها. سنع لا يعتمد على النية وحدها."
                }), 400

    db.execute(
        "UPDATE tasks SET status='منجزة', completed_at=? WHERE task_id=?",
        (datetime.utcnow().isoformat(), task_id)
    )

    updated_assets = []
    if task["decision_id"]:
        impacts = db.execute(
            "SELECT * FROM decision_asset_impacts WHERE decision_id=?", (task["decision_id"],)
        ).fetchall()

        if impacts:
            # القرار يرفع عدة أصول دفعة واحدة (الأساسي + الثانوية)
            for impact in impacts:
                asset = db.execute(
                    "SELECT * FROM assets WHERE asset_id=?", (impact["asset_id"],)
                ).fetchone()
                if asset:
                    new_score = min(asset["current_score"] + impact["score_impact"], 100)
                    db.execute(
                        "UPDATE assets SET current_score=?, updated_at=? WHERE asset_id=?",
                        (new_score, datetime.utcnow().isoformat(), impact["asset_id"])
                    )
                    updated_assets.append({
                        "asset_id": impact["asset_id"],
                        "asset_name": asset["asset_name"],
                        "new_score": new_score,
                        "is_primary": bool(impact["is_primary"]),
                    })
        else:
            # Fallback: لا يوجد سجل في decision_asset_impacts — نستخدم asset_id المفرد القديم
            decision = db.execute(
                "SELECT * FROM decisions WHERE decision_id=?", (task["decision_id"],)
            ).fetchone()
            if decision and decision["asset_id"]:
                asset = db.execute(
                    "SELECT * FROM assets WHERE asset_id=?", (decision["asset_id"],)
                ).fetchone()
                if asset:
                    new_score = min(asset["current_score"] + 5, 100)
                    db.execute(
                        "UPDATE assets SET current_score=?, updated_at=? WHERE asset_id=?",
                        (new_score, datetime.utcnow().isoformat(), decision["asset_id"])
                    )
                    updated_assets.append({
                        "asset_id": decision["asset_id"],
                        "asset_name": asset["asset_name"],
                        "new_score": new_score,
                        "is_primary": True,
                    })

    db.commit()
    return jsonify({
        "success": True,
        "data": {"task_id": task_id, "status": "منجزة", "updated_assets": updated_assets}
    })


# ------------------------------------------------------------------
# API — Cases (create new case = "فتح قضية")
# ------------------------------------------------------------------

@app.route("/api/companies/<company_id>/cases", methods=["POST"])
def create_case(company_id):
    body = request.get_json(force=True)
    db = get_db()
    import uuid
    case_id = "CS" + uuid.uuid4().hex[:6].upper()

    related_asset_id = body.get("related_asset_id")
    asset_name = None
    if related_asset_id:
        asset = db.execute("SELECT asset_name FROM assets WHERE asset_id=?", (related_asset_id,)).fetchone()
        asset_name = asset["asset_name"] if asset else None

    declared_problem = body.get("declared_problem", "")

    # ⚠ أسلوب تشخيص سنع: لا نفترض أن السبب مؤكَّد — السؤال الحقيقي يُصاغ دائمًا
    # كفرضية تحتاج اختبارًا، لا كحقيقة مسلَّم بها (وثيقة Diagnostic Framework، القاعدة الأولى).
    real_question = body.get("real_question") or (
        f"هل «{declared_problem}» فعلًا بسبب ضعف {asset_name}، أم يوجد سبب آخر لم يُكتشف بعد؟"
        if asset_name else
        f"ما السبب الجذري الحقيقي وراء: «{declared_problem}»؟"
    )

    db.execute("""INSERT INTO cases
        (case_id, company_id, case_title, case_type, case_status, declared_problem,
         real_question, related_asset_id, confidence_score)
        VALUES (?,?,?,?,?,?,?,?,?)""",
        (case_id, company_id, body.get("case_title", "قضية جديدة"), "Diagnostic Case", "Open",
         declared_problem, real_question, related_asset_id,
         45))  # ثقة أولية متواضعة — فرضية واحدة بدليل واحد لا تكفي بعد (قاعدة التثليث)

    # إن وُجد دليل أولي (سبب الربط بالأصل)، يُسجَّل فورًا كأول دليل للقضية
    initial_evidence = body.get("initial_evidence")
    if initial_evidence:
        evidence_id = "E" + uuid.uuid4().hex[:6].upper()
        db.execute("""INSERT INTO evidence (evidence_id, company_id, case_id, asset_id, title, source_type, confidence)
            VALUES (?,?,?,?,?,?,?)""",
            (evidence_id, company_id, case_id, related_asset_id, initial_evidence, "ملاحظة مباشرة", 50))

    db.commit()
    return jsonify({"success": True, "data": {"case_id": case_id, "real_question": real_question}}), 201


# ------------------------------------------------------------------
# API — Evidence (add evidence = "رفع دليل")
# ------------------------------------------------------------------

@app.route("/api/companies/<company_id>/evidence", methods=["POST"])
def add_evidence(company_id):
    body = request.get_json(force=True)
    db = get_db()
    import uuid
    evidence_id = "E" + uuid.uuid4().hex[:6].upper()
    db.execute("""INSERT INTO evidence (evidence_id, company_id, case_id, asset_id, title, source_type, confidence)
        VALUES (?,?,?,?,?,?,?)""",
        (evidence_id, company_id, body.get("case_id"), body.get("asset_id"),
         body.get("title", ""), body.get("source_type", "ملاحظة مباشرة"), body.get("confidence", 50)))
    db.commit()
    return jsonify({"success": True, "data": {"evidence_id": evidence_id}}), 201


# ------------------------------------------------------------------
# API — AI Analysis (أول اتصال ذكاء اصطناعي حقيقي في سنع)
# ------------------------------------------------------------------

@app.route("/api/evidence/<evidence_id>/analyze", methods=["POST"])
def analyze_evidence(evidence_id):
    db = get_db()
    evidence = db.execute("SELECT * FROM evidence WHERE evidence_id=?", (evidence_id,)).fetchone()
    if not evidence:
        return jsonify({"success": False, "error": "EVIDENCE_NOT_FOUND"}), 404

    case = None
    if evidence["case_id"]:
        case = db.execute("SELECT * FROM cases WHERE case_id=?", (evidence["case_id"],)).fetchone()

    assets = db.execute("SELECT asset_id, asset_type, asset_name, current_score FROM assets WHERE company_id=?",
                         (evidence["company_id"],)).fetchall()
    assets_list = "\n".join(f"- {a['asset_id']}: {a['asset_name']} ({a['asset_type']}, الدرجة الحالية: {a['current_score']})"
                             for a in assets)

    system_prompt = """أنت محرك تشخيص داخل نظام سنع (Sana) لرفع قيمة الشركات الصغيرة والمتوسطة.
مهمتك: قراءة دليل واحد (ملاحظة كتبها صاحب الشركة) وتحليله بموضوعية.
لا تجامل، ولا تفترض أكثر مما يقوله النص فعليًا.
أجب بصيغة JSON فقط، بلا أي نص قبله أو بعده، بهذا الشكل بالضبط:
{"summary": "ملخص من جملة واحدة لما يكشفه الدليل", "confidence_assessment": رقم من 0 إلى 100 يعكس قوة هذا الدليل بمفرده, "suggested_asset_id": "معرّف الأصل الأكثر ارتباطًا من القائمة المعطاة أو null إن لم يكن واضحًا", "reasoning": "سبب مختصر لماذا هذا الأصل تحديدًا"}"""

    user_prompt = f"""القضية: {case['case_title'] if case else 'غير مرتبطة بقضية'}
السؤال الحقيقي المطروح: {case['real_question'] if case else '—'}

الدليل المطلوب تحليله:
"{evidence['title']}"
(نوع المصدر: {evidence['source_type']}، الثقة المعلَنة عند الإضافة: {evidence['confidence']}٪)

أصول الشركة المتاحة:
{assets_list}

حلّل هذا الدليل تحديدًا."""

    result = ask_sana_ai(system_prompt, user_prompt)
    if "error" in result:
        return jsonify({"success": False, "error": "AI_ERROR", "message": result["error"]}), 502

    try:
        parsed = json.loads(result["raw_text"])
    except (json.JSONDecodeError, KeyError):
        return jsonify({"success": False, "error": "AI_PARSE_ERROR",
                         "message": "تعذّر فهم رد الذكاء الاصطناعي", "raw": result.get("raw_text", "")}), 502

    db.execute(
        "UPDATE evidence SET ai_analysis=?, ai_suggested_asset_id=?, confidence=? WHERE evidence_id=?",
        (parsed.get("summary", ""), parsed.get("suggested_asset_id"),
         parsed.get("confidence_assessment", evidence["confidence"]), evidence_id)
    )
    db.commit()

    return jsonify({"success": True, "data": parsed})


@app.route("/api/cases/<case_id>/analyze", methods=["POST"])
def analyze_case(case_id):
    """حوار فكري: يقرأ كل أدلة القضية معًا ويقيّم السؤال الحقيقي ككل، لا دليلًا واحدًا بمعزل."""
    db = get_db()
    case = db.execute("SELECT * FROM cases WHERE case_id=?", (case_id,)).fetchone()
    if not case:
        return jsonify({"success": False, "error": "CASE_NOT_FOUND"}), 404

    evidence_rows = db.execute("SELECT * FROM evidence WHERE case_id=?", (case_id,)).fetchall()
    evidence_text = "\n".join(f"- {e['title']} (مصدر: {e['source_type']}, ثقة: {e['confidence']}٪)"
                               for e in evidence_rows) or "لا توجد أدلة مسجَّلة بعد."

    assets = db.execute("SELECT asset_id, asset_type, asset_name, current_score FROM assets WHERE company_id=?",
                         (case["company_id"],)).fetchall()
    assets_list = "\n".join(f"- {a['asset_id']}: {a['asset_name']} (الدرجة: {a['current_score']})" for a in assets)

    system_prompt = """أنت محرك تشخيص داخل سنع. تقرأ كل الأدلة المسجَّلة لقضية واحدة معًا، لا كل دليل بمعزل.
قاعدة أساسية: لا تصدر حكمًا نهائيًا إن كانت الأدلة قليلة أو متضاربة — قل ذلك صراحة.
أجب بصيغة JSON فقط بهذا الشكل بالضبط:
{"overall_assessment": "تقييمك الكامل للسؤال الحقيقي بناءً على كل الأدلة مجتمعة، فقرة واحدة", "confidence_score": رقم 0-100, "recommended_decision_title": "عنوان قرار مقترح واحد قابل للتنفيذ", "recommended_reason": "سبب هذا القرار تحديدًا"}"""

    user_prompt = f"""عنوان القضية: {case['case_title']}
المشكلة كما وُصفت: {case['declared_problem']}
السؤال الحقيقي: {case['real_question']}

كل الأدلة المسجَّلة ({len(evidence_rows)}):
{evidence_text}

أصول الشركة:
{assets_list}

قيّم هذه القضية ككل الآن."""

    result = ask_sana_ai(system_prompt, user_prompt)
    if "error" in result:
        return jsonify({"success": False, "error": "AI_ERROR", "message": result["error"]}), 502

    try:
        parsed = json.loads(result["raw_text"])
    except (json.JSONDecodeError, KeyError):
        return jsonify({"success": False, "error": "AI_PARSE_ERROR",
                         "message": "تعذّر فهم رد الذكاء الاصطناعي", "raw": result.get("raw_text", "")}), 502

    db.execute("UPDATE cases SET ai_analysis=?, confidence_score=? WHERE case_id=?",
               (parsed.get("overall_assessment", ""), parsed.get("confidence_score", case["confidence_score"]), case_id))
    db.commit()

    return jsonify({"success": True, "data": parsed})


if __name__ == "__main__":
    fresh = init_db()
    seed_db()
    seed_decision_impacts()
    seed_frameworks()
    print("=" * 60)
    print("سنع — الخادم يعمل الآن")
    print("افتح المتصفح على: http://localhost:5000")
    print("=" * 60)
    app.run(debug=True, port=5000)
